﻿namespace xServer.Enums
{
    public enum PathType
    {
        File,
        Directory,
        Back
    }
}
