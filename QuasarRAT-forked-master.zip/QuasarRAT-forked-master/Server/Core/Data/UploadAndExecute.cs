﻿namespace xServer.Core.Data
{
    public static class UploadAndExecute
    {
        public static string FilePath { get; set; }
        public static bool RunHidden { get; set; }
    }
}
