﻿namespace xServer.Core.Data
{
    public static class VisitWebsite
    {
        public static string URL { get; set; }
        public static bool Hidden { get; set; }
    }
}
