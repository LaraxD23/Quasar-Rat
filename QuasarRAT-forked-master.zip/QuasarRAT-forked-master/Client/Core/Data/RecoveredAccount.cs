﻿namespace xClient.Core.Data
{
    public class RecoveredAccount
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string URL { get; set; }
        public string Application { get; set; }
    }
}
